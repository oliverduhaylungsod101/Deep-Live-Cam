"""Live speech-to-text captions from system audio (Windows WASAPI loopback).

Streams speaker/headphone mix through a local Vosk recognizer so partial
captions can update many times per second (Live Captions style), without
waiting on multi-second cloud round-trips.
"""

from __future__ import annotations

import json
import time
import urllib.request
import zipfile
from pathlib import Path
from typing import Any, Optional

import numpy as np
from PySide6.QtCore import QThread, Signal


TARGET_RATE = 16000
# Emit live overlay updates as soon as recognition text changes (~20 Hz cap).
MIN_EMIT_INTERVAL = 0.04
# Read ~30 ms of loopback audio per iteration for snappy partials.
CAPTURE_SECONDS = 0.03
DEVICE_CHECK_INTERVAL = 1.0
# If a device switch is not reflected by PortAudio's live enumeration, the old
# endpoint produces digital silence. Reopen the default endpoint after a short
# silent period, but not repeatedly more often than this interval.
SILENT_RECONNECT_AFTER = 2.0
SILENT_RECONNECT_INTERVAL = 6.0
OVERLAY_MAX_CHARS = 320  # unused legacy; overlay manages visible length via lines

MODEL_NAME = "vosk-model-small-en-us-0.15"
MODEL_URL = f"https://alphacephei.com/vosk/models/{MODEL_NAME}.zip"


def _models_root() -> Path:
    return Path(__file__).resolve().parent.parent / "models"


def _model_dir() -> Path:
    return _models_root() / MODEL_NAME


def captions_available() -> tuple[bool, str]:
    """Return (ok, message) describing whether STT deps are installed."""
    try:
        import pyaudiowpatch  # noqa: F401
    except ImportError:
        return False, "Install PyAudioWPatch (pip install PyAudioWPatch)"
    try:
        import vosk  # noqa: F401
    except ImportError:
        return False, "Install vosk (pip install vosk)"
    return True, "ok"


def ensure_vosk_model(status_cb=None) -> Path:
    """Download the small English Vosk model once into ./models/."""
    dest = _model_dir()
    if dest.is_dir() and any(dest.iterdir()):
        return dest

    root = _models_root()
    root.mkdir(parents=True, exist_ok=True)
    zip_path = root / f"{MODEL_NAME}.zip"

    if status_cb:
        status_cb("Downloading caption model (one-time)…")
    urllib.request.urlretrieve(MODEL_URL, zip_path)

    if status_cb:
        status_cb("Extracting caption model…")
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(root)
    try:
        zip_path.unlink(missing_ok=True)
    except Exception:
        pass

    if not dest.is_dir():
        raise RuntimeError(f"Vosk model missing after download: {dest}")
    return dest


def _to_mono_int16(frames: bytes, channels: int) -> np.ndarray:
    """Downmix interleaved int16 PCM to mono."""
    pcm = np.frombuffer(frames, dtype=np.int16)
    if channels <= 1:
        return pcm.copy()
    usable = (len(pcm) // channels) * channels
    pcm = pcm[:usable].reshape(-1, channels)
    return pcm.mean(axis=1).astype(np.int16)


def _resample_linear(pcm: np.ndarray, src_rate: int, dst_rate: int) -> np.ndarray:
    """Cheap linear resample for STT (quality is fine for speech)."""
    if src_rate == dst_rate or len(pcm) == 0:
        return pcm
    duration = len(pcm) / float(src_rate)
    n_out = max(1, int(round(duration * dst_rate)))
    x_old = np.linspace(0.0, 1.0, num=len(pcm), endpoint=False)
    x_new = np.linspace(0.0, 1.0, num=n_out, endpoint=False)
    return np.interp(x_new, x_old, pcm.astype(np.float32)).astype(np.int16)


def _find_wasapi_host(pa: Any) -> dict:
    for i in range(pa.get_host_api_count()):
        info = pa.get_host_api_info_by_index(i)
        if "WASAPI" in str(info.get("name", "")).upper():
            return info
    raise RuntimeError("WASAPI host API not available")


def _resolve_system_loopback(pa: Any) -> tuple[dict, dict]:
    """Resolve the current Windows default playback endpoint and its loopback."""
    wasapi_info = _find_wasapi_host(pa)
    default_speakers = pa.get_device_info_by_index(wasapi_info["defaultOutputDevice"])
    loopback = None
    if not default_speakers.get("isLoopbackDevice"):
        speaker_name = str(default_speakers.get("name", ""))
        for loop in pa.get_loopback_device_info_generator():
            if speaker_name and speaker_name in str(loop.get("name", "")):
                loopback = loop
                break
    else:
        loopback = default_speakers

    if loopback is None:
        loopback = pa.get_default_wasapi_loopback()

    sample_rate = int(loopback["defaultSampleRate"])
    channels = max(1, int(loopback["maxInputChannels"]))
    frames_per_buffer = max(256, int(sample_rate * CAPTURE_SECONDS))

    meta = {
        "name": str(loopback.get("name", "System audio")),
        "output_name": str(default_speakers.get("name", "")),
        "device_index": int(loopback["index"]),
        "sample_rate": sample_rate,
        "channels": channels,
        "frames_per_buffer": frames_per_buffer,
    }
    return loopback, meta


def _open_system_loopback(pa: Any) -> tuple[Any, dict]:
    """Open a WASAPI loopback stream on the current default playback device."""
    loopback, meta = _resolve_system_loopback(pa)
    stream = pa.open(
        format=pa.get_format_from_width(2),  # 16-bit PCM
        channels=meta["channels"],
        rate=meta["sample_rate"],
        input=True,
        input_device_index=meta["device_index"],
        frames_per_buffer=meta["frames_per_buffer"],
    )
    return stream, meta


def _device_key(meta: dict) -> tuple:
    """Stable identity used to detect Windows default-output changes."""
    return (
        meta.get("output_name", ""),
        meta.get("name", ""),
        int(meta.get("device_index", -1)),
        int(meta.get("sample_rate", 0)),
        int(meta.get("channels", 0)),
    )


def _overlay_text(committed: str, partial: str) -> str:
    """Join committed + partial without left-truncation (keeps line breaks stable)."""
    return f"{committed} {partial}".strip()


def _trim_committed(committed: str) -> str:
    """Drop oldest whole words only — never mid-string chops that break prefixes."""
    words = committed.split()
    if len(words) <= 120:
        return committed
    return " ".join(words[-120:])


class LiveCaptionWorker(QThread):
    """Background system-audio → streaming Vosk recognition loop."""

    # Live overlay text (partials + committed). Fired many times per second.
    captionReady = Signal(str)
    # Current unfinalized phrase, emitted immediately for the history box.
    captionPartial = Signal(str)
    # Finalized phrase for the history panel.
    captionFinal = Signal(str)
    # New speech after silence — overlay should accept a fresh shorter string.
    utteranceBegan = Signal()
    # Fired after recognizer state is wiped (e.g. post-submit history clear).
    historyReset = Signal()
    statusChanged = Signal(str)
    errorOccurred = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._stop = False
        self._reset_requested = False

    def stop(self) -> None:
        self._stop = True

    def request_reset(self) -> None:
        """Drop in-flight utterance so history can start fresh immediately."""
        self._reset_requested = True

    def run(self) -> None:
        ok, msg = captions_available()
        if not ok:
            self.errorOccurred.emit(msg)
            return

        import pyaudiowpatch as pyaudio
        from vosk import KaldiRecognizer, Model, SetLogLevel

        SetLogLevel(-1)

        try:
            model_path = ensure_vosk_model(
                status_cb=lambda t: self.statusChanged.emit(t)
            )
            model = Model(str(model_path))
        except Exception as exc:
            self.errorOccurred.emit(f"Caption model error: {exc}")
            return

        recognizer = KaldiRecognizer(model, TARGET_RATE)
        recognizer.SetWords(False)

        pa = pyaudio.PyAudio()
        stream: Optional[Any] = None
        try:
            stream, meta = _open_system_loopback(pa)
            self.statusChanged.emit(f"Listening to system audio: {meta['name']}")
        except Exception as exc:
            pa.terminate()
            self.errorOccurred.emit(f"No system audio loopback: {exc}")
            return

        sample_rate = int(meta["sample_rate"])
        channels = int(meta["channels"])
        frames_per_buffer = int(meta["frames_per_buffer"])

        committed = ""
        partial = ""
        last_emit = 0.0
        last_overlay = ""
        pending_text = ""
        last_speech_at = 0.0
        fresh_utterance = True
        last_device_check = time.monotonic()
        last_audio_activity = time.monotonic()
        last_silent_reconnect = time.monotonic()
        active_device_key = _device_key(meta)

        def reset_recognizer_state() -> None:
            nonlocal committed, partial, pending_text, last_overlay
            nonlocal fresh_utterance, last_speech_at
            try:
                recognizer.Reset()
            except Exception:
                pass
            committed = ""
            partial = ""
            pending_text = ""
            last_overlay = ""
            last_speech_at = 0.0
            fresh_utterance = True
            self.captionPartial.emit("")
            self.utteranceBegan.emit()

        def reopen_default_output(reason: str = "") -> None:
            nonlocal pa, stream, meta, sample_rate, channels
            nonlocal frames_per_buffer, active_device_key, last_device_check
            nonlocal last_audio_activity, last_silent_reconnect
            try:
                if stream is not None:
                    stream.stop_stream()
                    stream.close()
            except Exception:
                pass
            try:
                pa.terminate()
            except Exception:
                pass

            pa = pyaudio.PyAudio()
            stream, meta = _open_system_loopback(pa)
            sample_rate = int(meta["sample_rate"])
            channels = int(meta["channels"])
            frames_per_buffer = int(meta["frames_per_buffer"])
            active_device_key = _device_key(meta)
            last_device_check = time.monotonic()
            last_audio_activity = last_device_check
            last_silent_reconnect = last_device_check
            reset_recognizer_state()
            prefix = "Output changed — " if reason == "device_changed" else ""
            self.statusChanged.emit(
                f"{prefix}Listening to system audio: {meta['name']}"
            )

        def emit_overlay(force: bool = False) -> None:
            nonlocal last_emit, last_overlay, pending_text
            text = _overlay_text(committed, partial)
            # When speech pauses, Vosk clears the partial and the string shrinks.
            # Keep the last full caption so the overlay does not disappear —
            # but only within the same utterance (not after a real pause / reset).
            if last_overlay and text and not fresh_utterance:
                old_w = last_overlay.split()
                new_w = text.split()
                if len(new_w) < len(old_w) and old_w[: len(new_w)] == new_w:
                    return
            if not text and last_overlay:
                return
            pending_text = text
            now = time.monotonic()
            if text == last_overlay and not force:
                return
            if not force and (now - last_emit) < MIN_EMIT_INTERVAL:
                return
            last_emit = now
            last_overlay = text or last_overlay
            if text:
                self.captionReady.emit(text)

        try:
            while not self._stop:
                try:
                    if self._reset_requested:
                        self._reset_requested = False
                        reset_recognizer_state()
                        self.historyReset.emit()

                    # PortAudio binds a loopback stream to one endpoint. Windows
                    # can change the default output without invalidating that
                    # old stream, leaving it alive but permanently silent.
                    # Re-enumerate periodically using the SAME PyAudio instance.
                    # Creating/terminating a second instance can invalidate the
                    # active PortAudio stream on Windows.
                    now = time.monotonic()
                    if (now - last_device_check) >= DEVICE_CHECK_INTERVAL:
                        last_device_check = now
                        _loopback, current_meta = _resolve_system_loopback(pa)
                        if _device_key(current_meta) != active_device_key:
                            reopen_default_output("device_changed")

                    # Flush a throttled update if the interval has elapsed.
                    if (
                        pending_text
                        and pending_text != last_overlay
                        and (time.monotonic() - last_emit) >= MIN_EMIT_INTERVAL
                    ):
                        emit_overlay(force=True)

                    data = stream.read(frames_per_buffer, exception_on_overflow=False)
                    pcm = _to_mono_int16(data, channels)
                    now = time.monotonic()
                    peak = (
                        int(np.max(np.abs(pcm.astype(np.int32))))
                        if pcm.size
                        else 0
                    )
                    if peak > 8:
                        last_audio_activity = now
                    elif (
                        (now - last_audio_activity) >= SILENT_RECONNECT_AFTER
                        and (now - last_silent_reconnect)
                        >= SILENT_RECONNECT_INTERVAL
                    ):
                        # Some PortAudio builds keep reporting the old default
                        # endpoint after Windows switches outputs. A controlled
                        # full reopen refreshes the device list without running
                        # two PyAudio instances concurrently.
                        last_silent_reconnect = now
                        reopen_default_output("silent_endpoint")
                        continue
                    pcm16k = _resample_linear(pcm, sample_rate, TARGET_RATE)
                    raw = pcm16k.tobytes()

                    if recognizer.AcceptWaveform(raw):
                        result = json.loads(recognizer.Result())
                        phrase = (result.get("text") or "").strip()
                        partial = ""
                        self.captionPartial.emit("")
                        if phrase:
                            committed = _trim_committed(
                                f"{committed} {phrase}".strip()
                            )
                            self.captionFinal.emit(phrase)
                            last_speech_at = time.monotonic()
                            fresh_utterance = False
                        emit_overlay(force=True)
                    else:
                        partial_obj = json.loads(recognizer.PartialResult())
                        new_partial = (partial_obj.get("partial") or "").strip()
                        if new_partial != partial:
                            if new_partial:
                                now = time.monotonic()
                                # New speech after silence / cleared partial →
                                # allow a shorter string through the sticky overlay.
                                restarted = not partial
                                paused = bool(last_speech_at) and (
                                    now - last_speech_at
                                ) >= 0.35
                                if fresh_utterance or restarted or paused:
                                    last_overlay = ""
                                    fresh_utterance = False
                                    self.utteranceBegan.emit()
                                last_speech_at = now
                            partial = new_partial
                            self.captionPartial.emit(partial)
                            emit_overlay(force=True)
                except Exception as exc:
                    if self._stop:
                        break
                    self.statusChanged.emit(
                        f"Caption audio reconnecting: {exc}"
                    )
                    time.sleep(0.35)
                    try:
                        reopen_default_output("stream_error")
                    except Exception as reopen_exc:
                        self.errorOccurred.emit(
                            f"Caption audio unavailable: {reopen_exc}"
                        )
                        time.sleep(0.75)
        finally:
            try:
                # Flush any trailing partial as a final if useful.
                trailing = json.loads(recognizer.FinalResult())
                phrase = (trailing.get("text") or "").strip()
                if phrase:
                    self.captionFinal.emit(phrase)
            except Exception:
                pass
            try:
                if stream is not None:
                    stream.stop_stream()
                    stream.close()
            except Exception:
                pass
            try:
                pa.terminate()
            except Exception:
                pass
            self.statusChanged.emit("Captions stopped")
