@echo off
set "PATH=%~dp0ffmpeg\bin;%PATH%"
"%~dp0venv\Scripts\python.exe" "%~dp0run.py" --execution-provider cuda
